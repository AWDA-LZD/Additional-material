global Rs
global Rr
global Ls
global Lr
global Lm
global np
global J
global Tr
global siegma
Rs=10.98;%���ӵ���
Rr=15;%ת�ӵ���
Ls=0.3119;%�����Ը�
Lr=0.8;%ת���Ը�
Lm=0.297;%��ת�ӻ���
np=2;%������
J=0.008;%����ת������
Tr=Lr/Rr;%ת��ʱ�䳣��
siegma=1-(Lm^2)/(Ls*Lr);%©��ϵ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           ģ�Ͳ���
global a1
global c1
global d1
global f1
global g1
global a2
global b2
a1=(np^2)*Lm/(J*Lr);
c1=Lm/(siegma*Ls*Lr);
d1=(Rs*(Lr^2)+Rr*(Lm^2))/(siegma*Ls*(Lr^2));
f1=Lm/Tr;
g1=1/(siegma*Ls);
a2=1/Tr;
b2=Lm/(siegma*Ls*Lr*Tr);
global k1;
k1=15;
global k2;
k2=15;
global k3;
k3=15;
global k4;
k4=300;
global k5;
k5=300;
global h1;
h1=2;
global h2;
h2=2;
global h3;
h3=2;
global h4;
h4=100;
global h5;
h5=100;
global q1;
q1=1057/1001;
global p1;
p1=997/1001;
global lamda2;
lamda2=1;
global lamda3;
lamda3=1;
global lamda4;
lamda4=1;
global lamda5;
lamda5=1;
global o21;
o21=1;
global o22;
o22=1;
global o23;
o23=1;
global o31;
o31=1;
global o32;
o32=1;
global o33;
o33=1;
global o41;
o41=1;
global o42;
o42=1;
global o43;
o43=1;
global o51;
o51=1;
global o52;
o52=1;
global o53;
o53=1;