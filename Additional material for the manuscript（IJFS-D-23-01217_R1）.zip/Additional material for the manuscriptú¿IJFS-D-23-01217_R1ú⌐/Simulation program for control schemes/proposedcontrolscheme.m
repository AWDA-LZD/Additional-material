global Rs
global Rr
global Ls
global Lr
global Lm
global np
global J
global Tr
global siegma
Rs=10.98;%���ӵ���
Rr=15;%ת�ӵ���
Ls=0.3119;%�����Ը�
Lr=0.8;%ת���Ը�
Lm=0.297;%��ת�ӻ���
np=2;%������
J=0.008;%����ת������
Tr=Lr/Rr;%ת��ʱ�䳣��
siegma=1-(Lm^2)/(Ls*Lr);%©��ϵ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           ģ�Ͳ���
global a1
global c1
global d1
global f1
global g1
global a2
global b2
a1=(np^2)*Lm/(J*Lr);
c1=Lm/(siegma*Ls*Lr);
d1=(Rs*(Lr^2)+Rr*(Lm^2))/(siegma*Ls*(Lr^2));
f1=Lm/Tr;
g1=1/(siegma*Ls);
a2=1/Tr;
b2=Lm/(siegma*Ls*Lr*Tr);
global k11;
k11=10;
global k21;
k21=15;
global k31;
k31=300;
global k41;
k41=500;
global k51;
k51=26;
global k12;
k12=2;
global k22;
k22=2;
global k32;
k32=200;
global k42;
k42=500;
global k52;
k52=25;
global k13;
k13=2;
global k23;
k23=2;
global k33;
k33=2;
global k43;
k43=25;
global k53;
k53=25;
global phi11;
phi11=2;
global omiga11;
omiga11=2;
global phi12;
phi12=1;
global omiga12;
omiga12=2;
global A11;
A11=0.3;
global A12;
A12=0.3;
global phi21;
phi21=10;
global omiga21;
omiga21=2;
global phi22;
phi22=6;
global omiga22;
omiga22=2;
global A21;
A21=0.5;
global A22;
A22=0.5;
global phi31;
phi31=9;
global omiga31;
omiga31=2;
global phi32;
phi32=10;
global omiga32;
omiga32=2;
global A31;
A31=0.5;
global A32;
A32=0.5;
global phi41;
phi41=2;
global omiga41;
omiga41=2;
global phi42;
phi42=1;
global omiga42;
omiga42=2;
global A41;
A41=0.1;
global A42;
A42=0.1;
global phi51;
phi51=8;
global omiga51;
omiga51=2;
global phi52;
phi52=6;
global omiga52;
omiga52=2;
global A51;
A51=0.5;
global A52;
A52=0.5;
global H2;
H2=1;
global l2;
l2=1;
global H3;
H3=1;
global l3;
l3=1;
global H4;
H4=1;
global l4;
l4=1;
global H5;
H5=1;
global l5;
l5=1;
global r2;
r2=1;
global lamda21;
lamda21=5;
global lamda22;
lamda22=5;
global r3;
r3=1;
global lamda31;
lamda31=5;
global lamda32;
lamda32=5;
global r4;
r4=1;
global lamda41;
lamda41=5;
global lamda42;
lamda42=5;
global r5;
r5=1;
global lamda51;
lamda51=5;
global lamda52;
lamda52=5;
global umax1;
umax1=80;
global umin1;
umin1=-75;
global beta11;
beta11=20;
global beta12;
beta12=20;
global beta13;
beta13=20;
global umax2;
umax2=55;
global umin2;
umin2=-5;
global beta21;
beta21=40;
global beta22;
beta22=40;
global beta23;
beta23=40;
global p;
p=1397/1001;
global q;
q=497/1001;
global apxilon4;
apxilon4=1;
global l41;
l41=0.5*(3-q)*apxilon4^(q-1);
global l42;
l42=0.5*(q-1)*apxilon4^(q-3);
global apxilon5;
apxilon5=1;
global l51;
l51=0.5*(3-q)*apxilon5^(q-1);
global l52;
l52=0.5*(q-1)*apxilon5^(q-3);
global apxilon1;
apxilon1=1;
global l11;
l11=0.5*(3-q)*apxilon1^(q-1);
global l12;
l12=0.5*(q-1)*apxilon1^(q-3);
global apxilon2;
apxilon2=1;
global l21;
l21=0.5*(3-q)*apxilon2^(q-1);
global l22;
l22=0.5*(q-1)*apxilon2^(q-3);
global apxilon3;
apxilon3=1;
global l31;
l31=0.5*(3-q)*apxilon3^(q-1);
global l32;
l32=0.5*(q-1)*apxilon3^(q-3);



