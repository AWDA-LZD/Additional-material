function [sys,x0,str,ts] = model1(t,x,u,flag)
switch flag,
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case {2,4,9}
    sys=[];
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 5;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = [0 0 0 0.01 0];
str = [];
ts  = [0 0];

function sys=mdlDerivatives(t,x,u)
Rs=10.98+10.98*0.3*(1-exp(-0.5*t));
% Rs=10.98;
Rr=15+15*0.3*(1-exp(-0.5*t));%ת�ӵ���
Ls=0.3119;%�����Ը�
Lr=0.8;%ת���Ը�
Lm=0.297;%��ת�ӻ���
np=2;%������
J=0.008;%����ת������
Tr=Lr/Rr;%ת��ʱ�䳣��
siegma=1-(Lm^2)/(Ls*Lr);%©��ϵ��

a1=(np^2)*Lm/(J*Lr);
c1=Lm/(siegma*Ls*Lr);
d1=(Rs*(Lr^2)+Rr*(Lm^2))/(siegma*Ls*(Lr^2));
f1=Lm/Tr;
g1=1/(siegma*Ls);
a2=1/Tr;
b2=Lm/(siegma*Ls*Lr*Tr);

ust=u(1);%ust
usm=u(2);%usm
TL=u(3);

sys(1)=x(2);%dangle
sys(2)=a1*x(4)*x(3)-np*TL/J;%dw
sys(3)=-c1*x(2)*x(4)-d1*x(3)-f1*x(3)*x(5)/x(4)-x(2)*x(5)+g1*ust;%dist
sys(4)=-a2*x(4)+f1*x(5);%dPhir
sys(5)=b2*x(4)-d1*x(5)+f1*(x(3)^2)/x(4)+x(2)*x(3)+g1*usm;%dism

function sys=mdlOutputs(t,x,u)

sys(1)=x(1); %angle
sys(2)=x(2); %w
sys(3)=x(3); %ist
sys(4)=x(5); %ism